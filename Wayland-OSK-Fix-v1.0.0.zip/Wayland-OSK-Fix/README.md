# Wayland OSK Fix (Decky Plugin)

**Автор:** Kowalski  
**Версия:** 1.0.0  

Плагин для **Decky Loader** на Steam Deck (CachyOS / SteamOS), который исправляет работу экранной клавиатуры Steam (OSK) в сессиях Wayland (KDE Plasma) и Game Mode (Gamescope):
1. **Ввод русских символов в Desktop Mode:** Плагин перехватывает ввод экранной клавиатуры и передаёт аппаратные evdev-события через виртуальное ядро `/dev/uinput`, синхронизируя системную раскладку KDE.
2. **Исправление ввода единицы («1») в Game Mode:** Устраняет ошибку сканкод-маппинга в Gamescope при попытке напечатать русские буквы на экранной клавиатуре.
3. **Предотвращение дублирования нажатий:** Изолирует нативный вызов, обеспечивая единичный ввод каждого символа.
4. **Поддержка Backspace и специальных клавиш:** Корректно обрабатывает внутренние управляющие коды Steam.

---

## Установка в Decky Loader
Скопируйте директорию плагина в каталог плагинов Decky Loader:
```bash
sudo cp -r /home/viktor/Wayland-OSK-Fix /home/viktor/homebrew/plugins/
sudo systemctl restart plugin_loader
```
